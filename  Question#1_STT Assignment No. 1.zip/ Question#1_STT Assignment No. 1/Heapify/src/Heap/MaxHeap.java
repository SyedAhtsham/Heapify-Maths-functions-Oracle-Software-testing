package Heap;

import java.util.ArrayList;
import java.util.List;

public class MaxHeap {

	
	public List<Integer> traversedTree = new ArrayList<Integer>();

	private int[] hT;
	private int last_index;
	private int size;

	public MaxHeap() {
		this.size = 100;
		this.last_index = 0;
		hT = new int[this.size];
	}

	public MaxHeap(int size) {
		this.size = size;
		this.last_index = 0;
		hT = new int[this.size];
	}

	private int getParent(int index) {
		return (index - 1) / 2;
	}

	private int getLeftChild(int index) {
		return (2 * index) + 1;
	}

	private int getRightChild(int index) {
		return (2 * index) + 2;
	}

	private boolean isLeaf(int index) {
		if (index > (last_index / 2) && index <= last_index) {
			return true;
		}
		return false;
	}

	private void swap(int findex, int sindex) {
		int tmp;
		tmp = hT[findex];
		hT[findex] = hT[sindex];
		hT[sindex] = tmp;
	}

	private void maxHeapify(int index) {
		if (isLeaf(index))
			return;

		if (hT[index] < hT[getLeftChild(index)] || hT[index] < hT[getRightChild(index)]) {

			if (hT[getLeftChild(index)] > hT[getRightChild(index)]) {
				swap(index, getLeftChild(index));
				maxHeapify(getLeftChild(index));
			} else {
				swap(index, getRightChild(index));
				maxHeapify(getRightChild(index));
			}
		}
	}

	public void insert(int element) {
		hT[last_index] = element;

		int current = last_index;
		while (hT[current] > hT[getParent(current)]) {
			swap(current, getParent(current));
			current = getParent(current);
		}
		last_index++;
		
		traverseHeap();
	}

	public int getMax() {
		return hT[0];
	}

	public int extractMax() {
		int popped = hT[0];

		if (last_index == 0) {
			return popped;
		}

		hT[0] = hT[--last_index];
		maxHeapify(0);
		
		traverseHeap();
		return popped;
	}

	public boolean empty() {
		return last_index == 0;
	}
	
	public void traverseHeap() {
		traversedTree.clear();
		
		inOrderTraversal(0);
		
	}
	
	public void inOrderTraversal(int node) {
		if(node>=last_index) {
			return;
		}
		inOrderTraversal(getLeftChild(node));
		
		traversedTree.add(hT[node]);
		
//		System.out.print(hT[node]+" ");
		inOrderTraversal(getRightChild(node));
	}
	
	

	public static void main(String[] args) {
		
//		System.out.println("The Max Heap is ");
//
//		MaxHeap maxHeap = new MaxHeap();
//
//		maxHeap.insert(7);
//		maxHeap.insert(8);
//		maxHeap.insert(9);
//		maxHeap.insert(15);
//		maxHeap.insert(-55);
//		maxHeap.insert(34);

//		System.out.println("The max val is " + maxHeap.getMax());
//
//		while (!maxHeap.empty()) {
//			System.out.print(maxHeap.extractMax() + " ");
//		}

//		maxHeap.traverseHeap();
//		
	}
}
