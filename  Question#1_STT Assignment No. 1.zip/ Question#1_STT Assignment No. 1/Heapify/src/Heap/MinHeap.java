package Heap;

import java.util.ArrayList;
import java.util.List;

class MinHeap {
 
	
	public List<Integer> traversedTree = new ArrayList<Integer>();

    // Member variables of this class
    private int[] hT;
    private int last_index;
    private int size;
 
    // Initializing front as static with unity
    private static final int FRONT = 1;
 
    
    public MinHeap()
    {
 
        // This keyword refers to current object itself
        this.size = 100;
        this.last_index = 0;
 
        hT = new int[this.size + 1];
        hT[0] = Integer.MIN_VALUE;
    }
    
    // Constructor of this class
    public MinHeap(int size)
    {
 
        // This keyword refers to current object itself
        this.size = size;
        this.last_index = 0;
 
        hT = new int[this.size + 1];
        hT[0] = Integer.MIN_VALUE;
    }
 
    // Method 1
    // Returning the indexition of
    // the getParent for the node currently
    // at index
    private int getParent(int index) { return index / 2; }
 
    // Method 2
    // Returning the indexition of the
    // left child for the node currently at index
    private int getLeftChild(int index) { return (2 * index); }
 
    // Method 3
    // Returning the indexition of
    // the right child for the node currently
    // at index
    private int getRightChild(int index)
    {
        return (2 * index) + 1;
    }
 
    // Method 4
    // Returning true if the passed
    // node is a leaf node
    private boolean isLeaf(int index)
    {
 
        if (index > (last_index / 2)) {
            return true;
        }
 
        return false;
    }
 
    // Method 5
    // To swap two nodes of the heap
    private void swap(int findex, int sindex)
    {
 
        int tmp;
        tmp = hT[findex];
 
        hT[findex] = hT[sindex];
        hT[sindex] = tmp;
    }
 
    // Method 6
    // To heapify the node at index
   private void minHeapify(int index)
   {     
     if(!isLeaf(index)){
        
       //swap with the minimum of the two children
       int swapPos = hT[getLeftChild(index)]<hT[getRightChild(index)]?getLeftChild(index):getRightChild(index);
        
       if(hT[index]>hT[getLeftChild(index)] || hT[index]> hT[getRightChild(index)]){
         swap(index,swapPos);
         minHeapify(swapPos);
       }
        
     }      
   }
 
    // Method 7
    // To insert a node into the heap
    public void insert(int element)
    {
 
        if (last_index >= size) {
            return;
        }
 
        hT[++last_index] = element;
        int current = last_index;
 
        while (hT[current] < hT[getParent(current)]) {
            swap(current, getParent(current));
            current = getParent(current);
        }
        
		traverseHeap();

    }
    
    
    
 
    public int extractMin()
    {
 
        int popped = hT[FRONT];
        hT[FRONT] = hT[last_index--];
        minHeapify(FRONT);
 
		traverseHeap();

        return popped;
    }
    
    public boolean empty() {
    	return last_index==0;
    }
    
    public int getMin() {
    	return hT[FRONT];
    }
    
    
    
    public void traverseHeap() {
		traversedTree.clear();
		
		inOrderTraversal(1);
		
	}
	
	public void inOrderTraversal(int node) {
		if(node>=last_index+1) {
			return;
		}
		inOrderTraversal((2 * node) );
		
		traversedTree.add(hT[node]);
		
//		System.out.print(hT[node]+" ");
		inOrderTraversal((2 * node) + 1);
	}
	
	
 

    public static void main(String[] arg)
    {
 
   
        
//		int arr[] = { 22, 3, 9, -11, -63, 56, -56, 12, 2, 58 };
//
//		MinHeap heapObj = new MinHeap(arr.length);
//
//		for (int i = 1, k = 0; k < arr.length; i++, k++) {
//			heapObj.insert(arr[k]);
//		}
//		
//		heapObj.traverseHeap();
		
		
//		System.out.println("Min: " + heapObj.getMin());
//		System.out.println("The Min Heap is ");
//
//		while (!heapObj.empty()) {
//			System.out.print(heapObj.remove() + " ");
//		}
        
    }
}

