package Heap;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import Heap.MaxHeap;
import Heap.MinHeap;

public class Driver {

	public static List<ArrayList<Integer>> bigList = new ArrayList<ArrayList<Integer>>();
	public static List<ArrayList<Integer>> sortedBigList = new ArrayList<ArrayList<Integer>>();
	

	public static ArrayList<Integer> convertToIntegerList(String[] strArr) {
		int i = 0;
		ArrayList<Integer> list = new ArrayList<Integer>();

		if (strArr[i].equals("Max")) {
			list.add(1); // for A we used 1 at the end of the sequence
		} else if (strArr[i].equals("Min")) {
			list.add(0); // for D we used 0 at the end of the sequence
		} else {
			list.add(-1);
		}
		i++;
		for (; i < strArr.length; i++) {

			if (i == strArr.length - 1) {

				String str = strArr[i].substring(0, strArr[i].length() - 1);
				list.add(Integer.parseInt(str));
				break;

			}
			list.add(Integer.parseInt(strArr[i]));
		}

		return list;
	}

	public static void readAndWrite() throws IOException {

		
		
		FileWriter outputWriter = new FileWriter("observed_output.txt", true);
		
		
		
		File file = new File("input_file.txt");
		
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String str;
		str = br.readLine();
		while ((str = br.readLine()) != null) {
			br.readLine();
			String str2 = br.readLine();
			int element = -999999;
			if(str2 != null) {
			element = Integer.parseInt(str2.substring(7, str2.length()-1));
			}
			
			
			br.readLine();
			br.readLine();
			br.readLine();
			
			List<Integer> list = convertToIntegerList(str.split(" "));
			if(list.size()<=1) {
				outputWriter.append("Empty Heap!");
				outputWriter.append("\n\n\n");	
			}
			
			else if(list.get(0)==1) {
				MaxHeap maxHeap = new MaxHeap();
				for(int i=1; i<list.size(); i++) {
					maxHeap.insert(list.get(i));
				}
				
				
				for(int j=0; j < maxHeap.traversedTree.size(); j++) {
					outputWriter.append(maxHeap.traversedTree.get(j)+" ");
				}
				
				outputWriter.append("\n"+maxHeap.getMax()+'\n');
				
				maxHeap.insert(element);
				
				for(int j=0; j < maxHeap.traversedTree.size(); j++) {
					outputWriter.append(maxHeap.traversedTree.get(j)+" ");
				}
				
				outputWriter.append("\n"+maxHeap.extractMax()+"\n");
				for(int j=0; j < maxHeap.traversedTree.size(); j++) {
					outputWriter.append(maxHeap.traversedTree.get(j)+" ");
				}
				
				outputWriter.append("\n\n\n");
			}
				
				
				
				else if(list.get(0)==0) {
					
					MinHeap minHeap = new MinHeap();
					for(int i=1; i<list.size(); i++) {
						minHeap.insert(list.get(i));
					}
					
					
					for(int j=0; j < minHeap.traversedTree.size(); j++) {
						outputWriter.append(minHeap.traversedTree.get(j)+" ");
					}
					
					outputWriter.append("\n"+minHeap.getMin()+'\n');
					
					minHeap.insert(element);
					
					for(int j=0; j < minHeap.traversedTree.size(); j++) {
						outputWriter.append(minHeap.traversedTree.get(j)+" ");
					}
					
					outputWriter.append("\n"+minHeap.extractMin()+"\n");
					for(int j=0; j < minHeap.traversedTree.size(); j++) {
						outputWriter.append(minHeap.traversedTree.get(j)+" ");
					}
					
					outputWriter.append("\n\n\n");
				}
				
				else {
				
					outputWriter.append("Invalid Request Character!");
					outputWriter.append("\n\n\n");
				}
				
		}
				

		br.close();
		outputWriter.close();


	}
	
	
	
public static void Oracle(String observedOutputFile, String expectedOutputFile) throws IOException {
		
		
		
		
		String verdict = "";
		File observedFileReader = new File(observedOutputFile);
		File expectedFileReader = new File(expectedOutputFile);
		
		BufferedReader brO = null;
		BufferedReader brE = null;
		try {
			brO = new BufferedReader(new FileReader(observedFileReader));
			brE = new BufferedReader(new FileReader(expectedFileReader));
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		FileWriter outputWriter = new FileWriter("test_logFile.txt");
		outputWriter.write("  Test Case No.\t\t \t\t Expected Output\t\t\t\tObservedOutput\t\t\t\tVerdict\n");

		 

		
		
		int count = 1;
		do {
			
			boolean f1 = false, f2=false;
			String strO="",strE = "", string = "";
			do {
				
				string = brE.readLine();
				if(string==null) {
					f1 = true;
				}
				if(string!=null) {
					string = string.strip();
					f1 = true;
				}
				strE += " : "+ string;
				
			} while (string!=null && !string.isEmpty());
			
			
			string = "";
			
			do {
				string = brO.readLine();
				if(string==null) {
					f2 = true;
				}
				if(string!=null) {
					
					string = string.strip();
				}
				strO += " : "+ string;
				
			} while (string!=null && !string.isEmpty());

			if(f1 && f2) {
				break;
			}
			
			if(strO.equals(strE)) {
				verdict = "Pass";
			}
			else {
				verdict = "Fail";
			}
		
			outputWriter.write("\t"+count+"\t\t" + strE +"\t\t" + strO + "\t\t"+ verdict+"\n");

			count++;
			
		
			
			
		}
		while (((brO.readLine()) != null) && ((brE.readLine()) != null));
		
		brE.close();
		brO.close();

		outputWriter.close();		
	}
	
	
	

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		//readAndWrite();
		
		//System.out.println("Observed Output File Successfully Created...");
		
		Oracle("observed_output.txt", "expected_output.txt");
		
		System.out.println("Test Log File Successfully Created...");

	}

}
